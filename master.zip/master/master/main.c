/*
 * master.c
 *
 * Created: 1/14/2021 11:34:06 PM
 * Author : Nouran
 */ 


#include "LED.h"
#include "LCD.h"
#include "UART.h"
#include "SPI.h"

int main(void)
{
	Uint8t data_received = 0;
	LED0_Init();
	LED1_Init();
	LCD_Init();
	UART_Init();
	SPI_INIT();
	SPI_SLAVESELECT();
	LCD_Clear();
	LCD_Write_String((Uint8t*)"Welcome");
	_delay_ms(1000);
	LCD_Clear();
	/* Replace with your application code */
	while (1)
	{
		data_received = UART_Rx();
		/*
		if(data_received != 0)
		{
		//LCD_Clear();
		LCD_Write_Data(data_received);
		data_received = 0;
		}
		*/
		if (data_received == 'C' || data_received == 'c')
		{
			LCD_Clear();
			data_received = 0;
		}
		else if (data_received == 'A' || data_received == 'a')
		{
			LCD_Clear();
			LED0_ON();
			LCD_Write_Data(data_received);
			SPI_TRANSMIT(data_received);
			_delay_ms(1000);
			LED0_OFF();
			data_received = 0;
		}
		else if(data_received == 'B' || data_received == 'b')
		{
			LCD_Clear();
			LED1_ON();
			LCD_Write_Data(data_received);
			SPI_TRANSMIT(data_received);
			_delay_ms(1000);
			LED1_OFF();
			data_received = 0;
		}
		else
		{
			LCD_Clear();
			LCD_Write_Data(data_received);
			_delay_ms(1000);
			data_received = 0;
		}
	}
}


